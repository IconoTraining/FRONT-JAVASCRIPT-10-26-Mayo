// Una clase encapsulada es aquella que tiene todas sus propiedades
// privadas y se accede a ellas a través de los métodos get y set
class FechaEncapsulada{

    // Propiedades o atributos privadas
    #dia = 0;
    #mes = 0;
    #anyo = 0;

    constructor(dia, mes, anyo){
        this.setDia(dia);
        this.setMes(mes);
        this.setAnyo(anyo);
    }

    getDia(){
        return this.#dia;
    }

    setDia(dia){
        if (dia < 1 || dia > 30){
            alert("Dia no valido");
        } else {
            this.#dia = dia;
        }
    }

    getMes(){
        return this.#mes;
    }

    setMes(mes){
        if (mes < 1 || mes > 12){
            alert("Mes no valido");
        } else {
            this.#mes = mes;
        }
    }

    getAnyo(){
        return this.#anyo;
    }

    setAnyo(anyo){
        if (anyo != 2022 && anyo != 2023){
            alert("Año no valido");
        } else {
            this.#anyo = anyo;
        }
    }

    mostrarFecha(){
        // 18/5/2022
        return this.#dia + "/" + this.#mes + "/" + this.#anyo;
    }

}