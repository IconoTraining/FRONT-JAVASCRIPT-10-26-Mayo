function mostrar(){
    // id_formulario.name_campo.value
    console.log("Nombre: " + formulario.nombre.value);
    console.log("Password: " + formulario.pw.value);
    console.log("Apellido: " + formulario.apellido.value);
    console.log("Edad: " + formulario.edad.value);
    console.log("Email: " + formulario.email.value);
    console.log("Sitio Web: " + formulario.url.value);
    console.log("Telefono: " + formulario.telefono.value);
    console.log("Fecha nacimiento: " + formulario.nacimiento.value);
    console.log("Sexo: " + formulario.sexo.value);
    console.log("Fecha reserva: " + document.getElementById("reserva").value);
    console.log("Hora entrada: " + formulario.hora.value);
    console.log("Color: " + formulario.color.value);


    for (var i in document.getElementsByName("aficion")){
        if (document.getElementsByName("aficion")[i].checked){
            console.log("Hobbie: " + 
                document.getElementsByName("aficion")[i].value);
        }
    }

    console.log("Nivel de estudios: " + formulario.estudios.value);

    var cursos = document.getElementById("cursos").options;
    for (var i in cursos){
        if (cursos[i].selected){
            console.log("Cursos: " + cursos[i].text);
        }
    }

    console.log("Valoracion: " + formulario.valoracion.value);
    
}