class Figura{
    constructor(x,y){
        this.x = x;
        this.y = y;
    }

    area(){
        return 0;
    }

    mostrarInfo(){
        // [x,y]
        return "[" + this.x + "," + this.y + "]";
    }
}

class Circulo extends Figura{
    constructor(x,y,radio){
        // Estoy pasando x e y al constructor de la superclase
        super(x,y);
        this.radio = radio;
    }

    area(){
        return Math.PI * Math.pow(this.radio, 2);
    }

    mostrarInfo(){
        return super.mostrarInfo() + " radio: " + this.radio;
    }
}

class Rectangulo extends Figura{
    constructor(x, y, base, altura){
        // Estoy pasando x e y al constructor de la superclase
        super(x,y);
        this.base = base;
        this.altura = altura;
    }

    area(){
        return this.base * this.altura;
    }

    mostrarInfo(){
        return super.mostrarInfo() + " base: " + this.base + " altura: " + this.altura;
    }
}