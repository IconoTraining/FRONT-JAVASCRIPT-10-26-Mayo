// Declaracion explicita
var nombre = "Anabel";

// Declaracion implicita (sin utilizar var)
edad = 51;

// + -> operador de concatenacion
alert("Me llamo " + nombre +  " y tengo " + edad + " años");