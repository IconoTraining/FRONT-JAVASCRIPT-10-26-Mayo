//  3 variables booleanas para saber si tenemos aplicado el estilo o no
//  false: no tiene el estilo, true: si lo tiene
var estiloBorde = false;
var estiloColor = false;
var estiloSombra = false;

function borde(){
    // si no tiene borde se lo pongo, si lo tiene se lo quito
    if (!estiloBorde){
        // se lo pongo
        document.getElementById("cuadrado").style.border = "5px solid blue";
        document.getElementById("btnBorde").innerText = "Quitar borde";
        estiloBorde = true;
    } else {
        // se lo quito
        document.getElementById("cuadrado").style.border = "none";
        document.getElementById("btnBorde").innerText = "Aplicar borde";
        estiloBorde = false;
    }
}

function color(){
    if (!estiloColor){
        document.getElementById("cuadrado").style.backgroundColor = "pink";
        document.getElementById("btnColor").innerText = "Quitar color";
    } else {
        document.getElementById("cuadrado").style.backgroundColor = "darkgray";
        document.getElementById("btnColor").innerText = "Cambiar color";
    }
    estiloColor = !estiloColor;
}

function sombra(){
    if (!estiloSombra){
        document.getElementById("cuadrado").style.boxShadow = "-20px -10px 8px #666";
        document.getElementById("btnSombra").innerText = "Quitar sombra";
    }else {
        document.getElementById("cuadrado").style.boxShadow = "none";
        document.getElementById("btnSombra").innerText = "Poner sombra";
    }
    estiloSombra = !estiloSombra;
}





