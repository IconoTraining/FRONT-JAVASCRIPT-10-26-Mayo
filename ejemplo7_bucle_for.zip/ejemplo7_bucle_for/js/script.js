function cargarProvincias(){

    var arrayProvincias = ['Madrid', 'Valencia', 'Sevilla', 'Toledo'];

    var combo = document.getElementById("provincias");

    for(var indice in arrayProvincias){
        combo.innerHTML += "<option value=" + indice + ">" +
           arrayProvincias[indice] + "</option>";
    }
}

function cargarPoblaciones(){
    var seleccionado = document.getElementById("provincias").selectedIndex;
    var arrayPoblaciones = null;

    switch (seleccionado) {
        case 1:
            arrayPoblaciones = ['Getafe','Parla','Torrelodones'];
            break;
    
        case 2:
            arrayPoblaciones = ['Gandia','Oliva'];
            break;
        
        case 3:
            arrayPoblaciones = ['Dos Hermanas','Espartinas', 'Los Palacios'];
            break;
        
        case 4:
            arrayPoblaciones = ['Talavera','Trillo','Cebolla'];
            break;
    }

    document.getElementById("poblaciones").innerHTML = 
        "<option>--selecciona--</option>";

    for(var indice in arrayPoblaciones){
        document.getElementById("poblaciones").innerHTML += 
            "<option value=" + indice + ">" +
               arrayPoblaciones[indice] + "</option>";
    }

}