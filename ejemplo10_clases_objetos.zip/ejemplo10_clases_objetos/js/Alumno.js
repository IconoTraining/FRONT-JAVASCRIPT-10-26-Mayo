// Las clases comienzan por Mayuscula
class Alumno{

    // El constructor se invoca para crear el objeto o instancia
    // new Alumno("Juan", "Perez", 7.3)
    constructor(nombre, apellido, nota){
        // El puntero this apunta a la propia instancia
        this.nombre = nombre;
        this.apellido = apellido;
        this.nota = nota;
    }

    // Metodos
    mostrarInformacion(){
        return "Nombre: " + this.nombre + " Apellido: " + this.apellido +
            " Nota: " + this.nota;
    }

}

