function cambiarColor(){
    // Tengo que saber que boton se ha pulsado

    // event.target.id es el id del boton que se ha pulsado
    switch(event.target.id){
        case "btn1":
            document.getElementById(event.target.id).className = "rojo";
            break;
        case "btn2":
            document.getElementById(event.target.id).className = "verde";
            break;
        case "btn3":
            document.getElementById(event.target.id).className = "azul";
            break;

    }
}